﻿using ShoppingCart.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ShoppingCart.ViewModels
{
    public class ProductModel
    {
        public List<Product> _products { get; set; }

        public List<Product> findAll()
        {
            _products = new List<Product>{ new Product()
                {
                     Id = "1", Name = " Product1", Photo = "shoe-icon1.png", Price = 5.50
                     },
                    new Product()     {
                         Id = "2", Name = " Product2", Photo = "shoe-icon2.png", Price = 6.50
                    },
                    new Product()     {
                        Id = "3", Name = " Product3", Photo = "shoe-icon3.png", Price = 7.80
                    },
                    new Product()     {
                       Id = "4", Name = " Product4", Photo = "shoe-icon4.png", Price = 9.60
                     }
                  };
            return _products;       
                       
        }
        public Product find(string id)
        {
            List<Product> products = findAll();
            var prod = products.Where(a =>a.Id == id).FirstOrDefault();

            return prod;
        }
    }
}
